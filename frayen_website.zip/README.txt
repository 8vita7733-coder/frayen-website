Frayen — Social Media Expert (Free Website)
Files:
- index.html
- style.css
- script.js

How to publish (quick):
1) GitHub Pages:
   - Create a repository, upload these files to the repo root and enable Pages from the repository settings (branch: main, folder: /).
2) Netlify:
   - Drag-and-drop the ZIP into Netlify Drop (https://app.netlify.com/drop)
3) Vercel:
   - Create a new project and link the repo, or drag-and-drop.

WhatsApp contact included: +84 826 150 207 (wa.me link)

Note: The form uses mailto: (opens user's email client). To make forms work server-side, you'll need a backend or use a form service (Formspree, Netlify Forms, etc.).
