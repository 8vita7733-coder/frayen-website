// Smooth scrolling and simple nav toggle + form UX
document.addEventListener('DOMContentLoaded', function () {
  // dynamic year
  document.getElementById('year').textContent = new Date().getFullYear();

  // smooth scroll for internal links
  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
      var href = this.getAttribute('href');
      if (href.length > 1) {
        e.preventDefault();
        var el = document.querySelector(href);
        if (el) el.scrollIntoView({behavior:'smooth', block:'start'});
      }
    });
  });

  // mobile nav toggle
  var navToggle = document.getElementById('navToggle');
  var navLinks = document.querySelector('.nav-links');
  navToggle && navToggle.addEventListener('click', function () {
    navLinks.classList.toggle('show');
  });

  // optional: friendly submit message (form uses mailto so we provide guidance)
  var form = document.getElementById('contactForm');
  form && form.addEventListener('submit', function (e) {
    // Let mailto proceed; show a small toast
    setTimeout(function(){
      alert('Your email client should open now. If it does not, please contact us on WhatsApp: +84 826 150 207');
    }, 300);
  });

});
